
Commands to run:

python -m venv venv
source venv/bin/activate
pip install py4j
pip show py4j
python test_math_operations.py


Add the jar file back to package