from mypackage.math_operations import MathOperations

math_ops = MathOperations()
print(math_ops.add(5, 3))
print(math_ops.subtract(10, 4))
